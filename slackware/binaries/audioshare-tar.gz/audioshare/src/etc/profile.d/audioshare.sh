#!/bin/sh
# audioshare.sh -- point guest users at the host's shared PipeWire.
#
# Sourced at login. If the current user is listed as a GUEST in
# /etc/audioshare/audioshare.conf (and is NOT the host), export PULSE_SERVER
# so that all PulseAudio/PipeWire client apps talk to the host's PipeWire over
# localhost. The host user is left untouched (it must use its own PipeWire).
#
# SECURITY: see /etc/audioshare/audioshare.conf. As a guest you can see the
# host's microphone and monitors, and the host could see yours if roles were
# reversed. Trusted / same-person use only.

# Only meaningful for interactive users with a real uid.
[ -r /etc/audioshare/audioshare.conf ] || return 0 2>/dev/null || exit 0

# Read config without polluting the shell: subshell + grep the few keys.
_as_host=$(. /etc/audioshare/audioshare.conf 2>/dev/null; printf '%s' "$HOST_USER")
_as_guests=$(. /etc/audioshare/audioshare.conf 2>/dev/null; printf '%s' "$GUEST_USERS")
_as_bind=$(. /etc/audioshare/audioshare.conf 2>/dev/null; printf '%s' "${BIND:-127.0.0.1}")
_as_port=$(. /etc/audioshare/audioshare.conf 2>/dev/null; printf '%s' "${PORT:-4713}")

_me=$(id -un 2>/dev/null)

# Never redirect the host: it owns the card and runs the real PipeWire.
if [ -n "$_me" ] && [ "$_me" != "$_as_host" ]; then
    for _g in $_as_guests; do
        if [ "$_g" = "$_me" ]; then
            PULSE_SERVER="tcp:${_as_bind}:${_as_port}"
            export PULSE_SERVER
            break
        fi
    done
fi

unset _as_host _as_guests _as_bind _as_port _me _g
