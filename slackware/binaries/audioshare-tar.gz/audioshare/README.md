# audioshare

Share **one** PipeWire instance between several local user accounts on the same
machine, so they can all play audio through the same sound card **at the same
time**.

On a normal Linux system this is not possible: each user runs their own
PipeWire, and only one PipeWire can hold the sound card at a time. The others
fall back to a *Dummy Output* and stay silent. This is a kernel/ALSA reality,
not a distro limitation, and `systemd --user` does not change it either.

audioshare works around this with a **host + guests** model: one user (the
*host*) owns the card and runs PipeWire, and the other users (*guests*) connect
to the host's PipeWire over a **localhost-only** TCP socket. Every user's audio
is then mixed by the single host PipeWire and played on the one card.

This is a **proof of concept**. It proves the two-users-one-card case is
solvable. It is **not** a hardened, general-purpose tool -- see the security
section, and read it before you use it.

---

## ⚠️ Security -- read this first 
> YES ^^ I USE LLM to write code, Wow!!! 

A guest that connects to the host's PipeWire can see the host's **sources**,
not just its sinks. In practice a guest can:

* **Record from the host's microphone(s).**
* **Listen to whatever the host is playing**, via the sink monitor sources.

There is currently **no isolation** between host and guests. audioshare does
**not** yet block microphone or monitor access.

Because of that:

* Use audioshare **only** between accounts that belong to the **same person**,
  or users you **fully trust**.
* **Do not** use it on a multi-user machine shared by **different people**.
* The TCP socket is bound to `127.0.0.1` only. **Never** change `BIND` to a
  network-reachable address -- that would expose your microphone to the LAN.

Microphone/monitor blocking (via PipeWire's `block-record-stream` and access
control) is planned for a future version. Until then, assume every guest can
spy on the host.

---

## How it works

* **Host**: `audioshare-host enable` loads `module-native-protocol-tcp` on the
  host's own PipeWire, bound to `127.0.0.1:PORT`. `disable` unloads it. The
  sharing is **dynamic**: it is lost on reboot or when the host's
  pipewire-pulse restarts. Just run `enable` again to restore it.
* **Guest**: at login, `/etc/profile.d/audioshare.sh` checks whether the
  current user is listed as a guest (and is not the host). If so, it exports
  `PULSE_SERVER=tcp:127.0.0.1:PORT`, so PulseAudio client apps talk to the
  host. To also capture PipeWire-native apps (like mpv), the guest runs
  `audioshare-guest connect`, which stops the guest's own PipeWire so those
  apps fall through to the host too.

Nothing here replaces or modifies your per-user audio setup (for example
[audiod](https://forge.slackware.nl/rizitis/audiod)). audioshare only adds a
shared connection on top; the host still runs its normal PipeWire stack.

---

## Configuration

Everything is driven by `/etc/audioshare/audioshare.conf`:

```
HOST_USER=USER_NAME              # the user that owns the card and runs PipeWire
GUEST_USERS="TESTER_NAME"        # space-separated list of guest users
BIND=127.0.0.1                   # localhost only -- never a network address
PORT=4713                        # TCP port for the shared connection
```
> Replace ^^ in /etc/audioshare/audioshare.conf your real host user_name and the real tester_name 

---

## Usage

On the **host** account as user:

```
audioshare-host enable      # open the card to guests
audioshare-host status      # is sharing on?
audioshare-host disable     # close it again
```

On a **guest** account, after a fresh login (so `PULSE_SERVER` is set), run<br>
**before startx** (xfce):

```
audioshare-guest connect 
startx
```

`audioshare-guest connect` stops the guest's own PipeWire, so that **every**
app -- both PulseAudio apps (vlc, firefox) and PipeWire-native apps (mpv) --
plays on the host. Without it, only the PulseAudio apps reach the host; native
apps stay on the guest's local PipeWire and play into a silent Dummy Output.

To go back to your own audio:

```
audioshare-guest disconnect   # restart your local PipeWire
```

Check your state any time with `audioshare` or `audioshare-guest status`.
Both host and guest audio now play on the one card, mixed together.

### Why `connect` is needed

`PULSE_SERVER` (set automatically at login) only redirects apps that speak the
PulseAudio protocol. Apps that use the PipeWire-native API (such as mpv by
default) ignore it and talk to the guest's own local PipeWire instead -- which
does not hold the card, so they are silent. `audioshare-guest connect` stops
that local PipeWire, so those apps fall through to the host as well.

---

## Requirements

* PipeWire with the pulse compatibility layer (`pipewire-pulse`) on the host.
* `pactl` (PipeWire/PulseAudio utilities).
* Guests connect via the PulseAudio protocol over TCP (localhost).
NOTE: You have all these by default in a Slackware system.

---

## PoC 

1. Clean fresh boot init4 (sddm) to plasma6 and login
```
audioshare-host enable
open browser/app and play music -> plays on host
```
2. Ctrl+Alt+F2 login as guest_user <br>
```
echo $PULSE_SERVER                 # verify tcp:127.0.0.1:xxxx (from login)
audioshare-guest connect 
startx
play music on browser/app,mpv (native app) -> plays on host, mixed with host's audio
```

3. `reboot` all clear.

---

## Status / roadmap

* **v0 (this):** proof of concept. Host + guests share one card. No isolation.
  Trusted / same-person use only.
* **Planned:** (maybe if and when have free time) block guest microphone and monitor access
  (`block-record-stream`, PipeWire access control), so audioshare can be used
  safely between different people.

---

## License

Provided as-is, without warranty of any kind. See the security section: using
audioshare between untrusted users can expose microphones and audio.
