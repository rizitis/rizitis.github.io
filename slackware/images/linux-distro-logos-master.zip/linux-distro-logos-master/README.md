# linux-distro-logos
Here is a copy of the logos presented in http://fatduck.org/gnulinux/distro-logos.en.html they hope will be useful.

the images do not have great quality so I share the community hoping convert them to vectors, since I can not for lack of time.
