KERNEL_CONFIG=config-generic-x.y.z-xanmod1.x64 VERSION=x.y.z-xanmod1 /bin/bash kernel-source.SlackBuild
installpkg /tmp/kernel-source-x.y.z-noarch-1.txz
./kernel-xanmod.SlackBuild
installpkg /tmp/kernel-xanmod1-x.y.z-znver3-1.txz
./kernel-headers.SlackBuild
upgradepkg --reinstall --install-new /tmp/kernel-headers-x.y.z-x86-1.txz


grub-mkconfig -o /boot/grub/grub.cfg

sh /usr/share/mkinitrd/mkinitrd_command_generator.sh -k x.y.z-xanmod1 -a "-o /boot/initrd-x.y.z-xanmod1.img"
